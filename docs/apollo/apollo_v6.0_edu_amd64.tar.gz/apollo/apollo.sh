#!/usr/bin/env bash

###############################################################################
# Copyright 2021 The Apollo Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
###############################################################################

CURR_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
source ${CURR_DIR}/scripts/apollo.bashrc

CONTAINER="apollo_runtime_standalone_${USER}"

DIRS=("data/log" "data/bag" "data/core" "modules/calibration/data" "modules/map/data" "output")

for dir in ${DIRS[@]}; do
    if [[ ! -d "${CURR_DIR}/${dir}" ]]; then
      mkdir -p "${CURR_DIR}/${dir}"
    fi
done

cat <<EOF
Welcome to
    ___                ____    
   /   |  ____  ____  / / /___ 
  / /| | / __ \/ __ \/ / / __ \\
 / ___ |/ /_/ / /_/ / / / /_/ /
/_/  |_/ .___/\____/_/_/\____/ 
      /_/ 
EOF

docker ps -a --format "{{.Names}}" | grep "^${CONTAINER}$" >/dev/null
if [ $? -eq 0 ]; then
    echo "Found existing container. If you need a fresh one, run 'docker rm -f ${CONTAINER}' out of the container first."
    docker start ${CONTAINER} >/dev/null
    bash ${CURR_DIR}/scripts/runtime_into.sh
else
    bash ${CURR_DIR}/scripts/runtime_start.sh
    if [ $? -eq 0 ]; then
      bash ${CURR_DIR}/scripts/runtime_into.sh
    fi
fi
