# 安装指南

本指南使用markdown格式编写，推荐使用Typora或其他支持该格式的文件浏览器查看。

本文将介绍使用Apollo前的所有准备工作：

- 安装 Ubuntu Linux
- 安装 NVIDIA GPU 驱动
- 安装 Docker Engine
- 安装 NVIDIA Container Toolkit
  
本文假定用户已具备基本Linux工作知识。

## 安装Ubuntu Linux

目前只在[Ubuntu 18.04.5 LTS (Bionic Beaver)](https://releases.ubuntu.com/18.04.5/)中测试过Apollo。因此我们推荐使用Ubuntu 18.04.5+（包括Ubuntu 20.04）作为主机的操作系统。 安装Ubuntu 18.04+的步骤请参见官方指南[Tutorial from ubuntu.com on How to Install Ubuntu](https://ubuntu.com/tutorials/install-ubuntu-desktop)。请依据指南完成系统的安装步骤，并在完成安装后更新相关软件：

```bash
sudo apt-get update
sudo apt-get upgrade
```

若要完成更新，需要保证网络连接。

## 安装NVIDIA GPU驱动

车上的Apollo运行环境需要依赖NVIDIA GPU驱动。根据[How to Install NVIDIA Driver](https://github.com/NVIDIA/nvidia-docker/wiki/Frequently-Asked-Questions#how-do-i-install-the-nvidia-driver)的介绍，在Ubuntu上的推荐安装方式是通过apt-get命令，或使用官方"runfile"（www.nvidia.com/en-us/drivers/unix/）。 对于Ubuntu 18.04+，只需要简单执行以下命令即可：

```bash
sudo apt-get update
sudo apt-add-repository multiverse
sudo apt-get update
sudo apt-get install nvidia-driver-460
```

可以输入`nvidia-smi`来校验NVIDIA GPU驱动是否在正常运行（可能需要在安装后重启系统以使驱动生效）。如果成功，则会出现以下信息：

```bash
Prompt> nvidia-smi
Mon Jan 25 15:51:08 2021
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 460.27.04    Driver Version: 460.27.04    CUDA Version: 11.2     |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|                               |                      |               MIG M. |
|===============================+======================+======================|
|   0  GeForce RTX 3090    On   | 00000000:65:00.0  On |                  N/A |
| 32%   29C    P8    18W / 350W |    682MiB / 24234MiB |      7%      Default |
|                               |                      |                  N/A |
+-------------------------------+----------------------+----------------------+

+-----------------------------------------------------------------------------+
| Processes:                                                                  |
|  GPU   GI   CI        PID   Type   Process name                  GPU Memory |
|        ID   ID                                                   Usage      |
|=============================================================================|
|    0   N/A  N/A      1286      G   /usr/lib/xorg/Xorg                 40MiB |
|    0   N/A  N/A      1517      G   /usr/bin/gnome-shell              120MiB |
|    0   N/A  N/A      1899      G   /usr/lib/xorg/Xorg                342MiB |
|    0   N/A  N/A      2037      G   /usr/bin/gnome-shell               69MiB |
|    0   N/A  N/A      4148      G   ...gAAAAAAAAA --shared-files      105MiB |
+-----------------------------------------------------------------------------+
```

## 安装Docker Engine

Apollo 6.0+ 依赖于Docker 19.03+。参照[Install Docker Engine on Ubuntu](https://docs.docker.com/engine/install/ubuntu/)安装docker引擎。 Ubuntu上的Docker-CE也可以通过Docker提供的官方脚本安装：

```bash
curl https://get.docker.com | sh
sudo systemctl start docker && sudo systemctl enable docker
```

你可以自由选择喜欢的方式，但别忘了执行[Linux上的后续操作说明](https://docs.docker.com/engine/install/linux-postinstall/)。此外，还可以参照：[使用非root权限运行docker](https://docs.docker.com/engine/install/linux-postinstall/#manage-docker-as-a-non-root-user)，和[配置开机启动docker](https://docs.docker.com/engine/install/linux-postinstall/#configure-docker-to-start-on-boot)。

## 安装 NVIDIA Container Toolkit

基于Apollo的CUDA的docker镜像需要依赖于NVIDIA Container Toolkit。 可以通过运行以下命令来安装NVIDIA Container Toolkit。

```bash
distribution=$(. /etc/os-release;echo $ID$VERSION_ID)
curl -s -L https://nvidia.github.io/nvidia-docker/gpgkey | sudo apt-key add -
curl -s -L https://nvidia.github.io/nvidia-docker/$distribution/nvidia-docker.list | sudo tee /etc/apt/sources.list.d/nvidia-docker.list
sudo apt-get -y update
sudo apt-get install -y nvidia-docker2
```

最后，别忘了重启Docker以使改动生效。

```bash
sudo systemctl restart docker
```

可参考[NVIDIA Container Toolkit Installation Guide](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html)以获取详细信息。

## 使用Apollo

安装完上述环境后,执行本目录下的`apollo.sh`脚本即可使用Apollo

```bash
./apollo.sh
```

如果脚本执行成功，你将进入Apollo的运行容器：

```bash
[user@in-runtime-docker:/apollo]$
```

在容器内可以直接使用Apollo提供的功能，无需执行构建过程。

**Note:** 本文件夹下的一些目录会在容器中挂载，其中：modules/calibration/data用于保存车辆数据，modules/map/data用来保存地图数据，用户可将自己的车辆或地图文件拷贝到这两个文件夹中使用。
