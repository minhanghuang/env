/*
* Copyright (C) Trunk Technology, Inc. - All Rights Reserved
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
*
* Written by Minhang Huang <huangminhang@trunk.tech>, ${DATE} ${TIME}
*/
#if (${HEADER_FILENAME})
#[[#include]]# "${HEADER_FILENAME}"
#end
